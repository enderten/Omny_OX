
// Omny_OX boot integration: keep layout, only fade at end (no reveal)
(function(){
  function endBoot(){
    var fade = document.querySelector('#omny_boot .fade');
    if (fade) fade.style.opacity = '1';
    setTimeout(function(){
      var boot = document.getElementById('omny_boot');
      if (boot) boot.remove();
    }, 650);
  }
  var wrap = document.createElement('div');
  wrap.id = 'omny_boot';
  wrap.innerHTML = '<video id="omny_vid" src="assets/Omny_OX_NEXT.mp4" autoplay muted playsinline></video><div class="fade"></div>';
  document.body.appendChild(wrap);
  var v = document.getElementById('omny_vid');
  var timer = setTimeout(endBoot, 5700);
  v.addEventListener('ended', function(){ clearTimeout(timer); endBoot(); });
})();
