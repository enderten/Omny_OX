/* ==== Config ==== */
const WALLPAPERS = [
  'wallpapers/wallpaper1.jpg',
  'wallpapers/wallpaper2.jpg',
  'wallpapers/wallpaper3.jpg'
];
const DEFAULT_REMOTE_WALLPAPER = 'https://512pixels.net/wp-content/uploads/2025/06/26-Tahoe-Light-6K-thumb.jpeg';

/* ==== Utils ==== */
const qs = (sel, root=document) => root.querySelector(sel);
const qsa = (sel, root=document) => [...root.querySelectorAll(sel)];

/* ==== Clock ==== */
function updateClock(){
  const el = qs('#clock');
  if(!el) return;
  const now = new Date();
  const h = now.getHours().toString().padStart(2,'0');
  const m = now.getMinutes().toString().padStart(2,'0');
  el.textContent = `${h}:${m}`;
}
setInterval(updateClock, 1000); updateClock();

/* ==== Notifications ==== */
function notify(title='Notificación', body=''){
  const wrap = qs('#toasts');
  const box = document.createElement('div');
  box.className = 'toast';
  box.innerHTML = `<div class="title">${title}</div><div class="body">${body}</div>`;
  wrap.appendChild(box);
  setTimeout(()=>{
    box.style.transition = 'opacity .15s, transform .15s';
    box.style.opacity = '0';
    box.style.transform = 'translateY(-6px)';
    setTimeout(()=>box.remove(), 180);
  }, 4200);
}

/* ==== Launchpad ==== */
function toggleLaunchpad(force){
  const lp = qs('#launchpad');
  const show = (typeof force === 'boolean') ? force : lp.classList.contains('hidden');
  lp.classList.toggle('hidden', !show);
}

/* ==== Apps ==== */
function openApp(app){
  switch(app){
    case 'settings': openSettings(); break;
    case 'google': window.open('https://www.google.com', '_blank'); break;
    case 'youtube': window.open('https://www.youtube.com', '_blank'); break;
    case 'drive': window.open('https://www.drive.google.com', '_blank'); break;
    case 'prime': window.open('https://www.primevideo.com', '_blank'); break;
    case 'camera': openCamera(); break;
    default:
      notify('App no implementada', app);
  }
}

/* ==== Dock Helpers ==== */
function setDockActive(app, on=true){
  const el = qs(`#dock img[data-app="${app}"]`);
  if(!el) return;
  el.classList.toggle('active', !!on);
}

/* ==== Camera ==== */
let camStream = null;
function openCamera(){
  const win = qs('#camera-window');
  win.classList.remove('hidden');
  setDockActive('camera', true);
  const video = qs('#cam-video');
  if(navigator.mediaDevices?.getUserMedia){
    navigator.mediaDevices.getUserMedia({ video:true, audio:false })
      .then(stream => { camStream = stream; video.srcObject = stream; })
      .catch(err => { notify('Cámara no disponible', err.message || 'Permiso denegado'); });
  }else{
    notify('No soportado', 'getUserMedia no está disponible en este navegador.');
  }
}
function closeCamera(){
  const win = qs('#camera-window');
  win.classList.add('hidden');
  setDockActive('camera', false);
  const video = qs('#cam-video');
  if(camStream){
    camStream.getTracks().forEach(t=>t.stop());
    camStream = null;
  }
  if(video) video.srcObject = null;
}

/* ==== Wallpapers ==== */
function applyWallpaper(url){
  document.body.style.backgroundImage = `url('${url}')`;
}
function loadWallpaperFromStorage(){
  const saved = localStorage.getItem('ranita.wallpaper');
  if(saved){
    applyWallpaper(saved);
  }else{
    applyWallpaper(DEFAULT_REMOTE_WALLPAPER);
  }
}
function setWallpaper(url){
  localStorage.setItem('ranita.wallpaper', url);
  applyWallpaper(url);
  notify('Wallpaper aplicado', url.split('/').pop());
}
function openWallpapers(){
  const win = qs('#wallpapers-window');
  const grid = qs('#wall-grid');
  grid.innerHTML = '';
  const all = [...WALLPAPERS];
  all.forEach((url, i)=>{
    const tile = document.createElement('div');
    tile.className = 'tile';
    tile.innerHTML = `<img src="${url}" alt="wallpaper ${i+1}"/><div class="name">${url.split('/').pop()}</div>`;
    tile.onclick = ()=> setWallpaper(url);
    grid.appendChild(tile);
  });
  win.classList.remove('hidden');
}
function closeWallpapers(){
  qs('#wallpapers-window').classList.add('hidden');
}

/* ==== Fullscreen for windows ==== */
function toggleFullscreen(id){
  const win = qs('#'+id);
  if(!win) return;
  win.classList.toggle('fullscreen');
}

/* ==== Init ==== */
/* Omny_OX: set default Liquid Glass wallpaper if none */
(function(){
  try{
    var hasOmny = localStorage.getItem('omny.wallpaper');
    var hasRanita = localStorage.getItem('ranita.wallpaper');
    if(!hasOmny && !hasRanita){
      var def = 'wallpapers/liquid-glass.jpg';
      try { localStorage.setItem('omny.wallpaper', def); } catch(e){}
      var bg = document.getElementById('wallpaper') || document.querySelector('.wallpaper');
      if(bg) bg.style.backgroundImage = "url('" + def + "')";
    }
  }catch(e){}
})();
document.addEventListener('DOMContentLoaded', ()=>{
  // Dock animations & active glow
  (function(){
    var dock = document.querySelector('#dock');
    if(!dock) return;
    dock.querySelectorAll('img,[data-app]').forEach(function(el){
      el.addEventListener('click', function(){
        dock.querySelectorAll('img').forEach(i=> i.classList && i.classList.remove('active'));
        if (el.tagName === 'IMG') el.classList.add('active');
      });
    });
  })();
  // Omny_OX clock bubble (hide old bar clock if exists)
  (function(){
    var old = document.querySelector('#clock');
    if (old) old.style.display = 'none';
    var bubble = document.createElement('div');
    bubble.id = 'clockBubble';
    bubble.innerHTML = '<div class="time">00:00</div><div class="date"></div>';
    document.body.appendChild(bubble);
    function upd(){
      var now = new Date();
      var hh = String(now.getHours()).padStart(2,'0');
      var mm = String(now.getMinutes()).padStart(2,'0');
      var dd = now.toLocaleDateString(undefined, {weekday:'short', day:'2-digit', month:'short'});
      bubble.querySelector('.time').textContent = hh + ':' + mm;
      bubble.querySelector('.date').textContent = dd;
    }
    upd(); setInterval(upd, 1000 * 30);
  })();
  loadWallpaperFromStorage();
  // Bienvenida
  setTimeout(()=> notify('Ranita OS', 'Bienvenido, Mau 🐸⚡🚗'), 800);

  // Escape cierra modales si están fullscreen
  document.addEventListener('keydown', (e)=>{
    if(e.key === 'Escape'){
      qsa('.app-window').forEach(w=> w.classList.remove('fullscreen'));
    }
  });
});

/* ==== Settings (Omny_OX) ==== */
function openSettings(){
  const existing = document.getElementById('settings-window');
  if(existing){ existing.classList.remove('hidden'); return; }
  const win = document.createElement('div');
  win.id = 'settings-window';
  win.className = 'app-window';
  win.innerHTML = `
    <div class="window-bar">
      <div class="traffic">
        <button class="dot dot-green" title="Pantalla completa" onclick="toggleFullscreen('settings-window')"></button>
        <button class="dot dot-red" title="Cerrar" onclick="document.getElementById('settings-window').classList.add('hidden')"></button>
      </div>
      <span>⚙️ Ajustes</span>
      <div class="window-actions"></div>
    </div>
    <div class="window-body">
      <div style="display:grid; gap:14px;">
        <div>
          <div style="font-weight:700; margin-bottom:6px;">Tema</div>
          <label><input type="radio" name="omny_theme" value="dark"> Oscuro</label>
          <label style="margin-left:12px;"><input type="radio" name="omny_theme" value="light"> Claro</label>
        </div>
        <div>
          <div style="font-weight:700; margin-bottom:6px;">Color de acento</div>
          <input type="color" id="omny_accent" value="#4bb3ff">
        </div>
        <div>
          <div style="font-weight:700; margin-bottom:6px;">Volumen del sistema</div>
          <input type="range" id="omny_volume" min="0" max="1" step="0.01" value="0.5">
        </div>
      </div>
    </div>`;
  document.body.appendChild(win);
  const themeSaved = localStorage.getItem('omny.theme') || 'dark';
  document.querySelectorAll('input[name="omny_theme"]').forEach(r=>{
    r.checked = (r.value === themeSaved);
    r.addEventListener('change', ()=>{
      localStorage.setItem('omny.theme', r.value);
      document.documentElement.setAttribute('data-omny-theme', r.value);
    });
  });
  const accent = document.getElementById('omny_accent');
  const savedAccent = localStorage.getItem('omny.accent') || '#4bb3ff';
  accent.value = savedAccent;
  accent.addEventListener('input', ()=>{
    localStorage.setItem('omny.accent', accent.value);
    document.documentElement.style.setProperty('--accent', accent.value);
  });
  const vol = document.getElementById('omny_volume');
  const savedVol = parseFloat(localStorage.getItem('omny.volume') || '0.5');
  vol.value = savedVol;
  vol.addEventListener('input', ()=>{
    localStorage.setItem('omny.volume', vol.value);
  });
}
